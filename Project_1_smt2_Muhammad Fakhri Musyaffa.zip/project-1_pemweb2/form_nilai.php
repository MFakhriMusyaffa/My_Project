<?php
    include_once 'header.php';
    include_once 'sidebar.php';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Form Nilai Mahasiswa</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Form Nilai Mahasiswa</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Default box -->
                    <div class="card">
                        <div class="card-body">
                            <form menthod="GET" action="form_nilai.php">
                                <div class="form-group row">
                                    <label for="nama_lengkap" class="col-3 col-form-label">Nama Lengkap</label> 
                                    <div class="col-8">
                                    <input id="nama_lengkap" name="nama_lengkap" type="text" class="form-control" placeholder="Nama Lengkap">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="Matkul" class="col-3 col-form-label">Mata kuliah</label> 
                                    <div class="col-8">
                                    <select id="Matkul" name="Matkul" class="custom-select">
                                        <option value="DDP">Dasar Dasar Pemerongaman</option>
                                        <option value="Basdat">Basis data</option>
                                        <option value="PW">Pemerogaman Web</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="nilai_uts" class="col-3 col-form-label">Nilai UTS</label> 
                                    <div class="col-8">
                                    <input id="nilai_uts" name="nilai_uts" type="text" class="form-control"  placeholder="Nilai UTS ">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="nilai_uas" class="col-3 col-form-label">Nilai Uas</label> 
                                    <div class="col-8">
                                    <input id="nilai_uas" name="nilai_uas" type="text" class="form-control" placeholder="Nilai Uas ">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="nilai_tugas" class="col-3 col-form-label">Nilai Tugas</label> 
                                    <div class="col-8">
                                    <input id="nilai_tugas" name="nilai_tugas" type="text" class="form-control"  placeholder="Nilai Tugas">
                                    </div>
                                </div> 
                                <div class="form-group row">
                                    <div class="offset-4 col-8">
                                    <button name="submit" type="submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </div>
                            </form>
                            <?php
                                error_reporting(0);
                                
                                $nama = $_GET['nama_lengkap'];
                                $matkul = $_GET['Matkul'];
                                $nilai_uts = $_GET['nilai_uts'];
                                $nilai_uas = $_GET['nilai_uas'];
                                $nilai_tugas = $_GET['nilai_tugas'];

                                echo '<br/> Nama : '.$nama; 
                                echo '<br/> Mata Kuliah : '.$matkul; 
                                echo '<br/>Nilai UTS : '.$nilai_uts;
                                echo '<br/>Nilai UAS : '.$nilai_uas; 
                                echo '<br/>Nilai Tugas :'.$nilai_tugas; 
                            ?>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>

<?php
    include_once 'footer.php';
?>