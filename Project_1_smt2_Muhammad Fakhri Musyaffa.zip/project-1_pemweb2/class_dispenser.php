<?php
  include_once 'header.php';
  include_once 'sidebar.php';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Class Dispenser</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Class Dispenser</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Default box -->
                    <div class="card">
                        <div class="card-body">
                            <?php

                                class Dispenser{
                                    public $volume;
                                    public $hargaSegelas;
                                    public $volumeGelas;
                                    public $namaMinuman;
                                    public const PHI = 3.14;
                                    public $jari_jari;
                                    public $tinggi;

                                    public function __construct($jari, $tinggi){
                                        $this -> jari_jari = $jari;
                                        $this -> tinggi = $tinggi;
                                        echo "<br/>Jari-jari : " . $jari . " cm";
                                        echo "<br/>Tinggi : " . $tinggi . " cm";
                                    }

                                    public function VolumeWadah(){
                                        return self::PHI * $this -> jari_jari * $this -> jari_jari * $this -> tinggi;
                                    }
                                }

                                class Harga extends Dispenser{

                                    public function __construct($hargaSegelas){
                                        $this -> hargaSegelas = $hargaSegelas;
                                        echo"<br>";
                                        echo "<br/> Diketahui : ";
                                        echo "<br/>Harga satu gelas : Rp." . $hargaSegelas . ",-";
                                    }
                                    public function Harga(){
                                        return $this -> hargaSegelas * 6 ;
                                    }
                                }
                                    
                                    echo "<br/>  PHI : " . Dispenser :: PHI;
                                    $volumeWadah = new Dispenser(30, 90);
                                    $harga = new Harga(2000);
                                    echo "<br/> Volume Wadah : " . $volumeWadah -> VolumeWadah() . " cm3";
                                    echo "<br/> Harga 6 Gelas :  Rp. " . $harga -> Harga() . ",-";

                            ?>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>

<?php
  include_once 'footer.php';
?>