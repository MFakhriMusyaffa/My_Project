<?php
    include_once 'header.php';
    include_once 'sidebar.php';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Form Belanja</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Form Belanja</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Default box -->
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-8">
                                    <form method="POST" action="form_belanja.php">
                                        <div class="form-group row">
                                            <label for="customer" class="col-2 col-form-label">Customer</label>
                                            <div class="col-7">
                                                <input id="customer" name="customer" placeholder="Nama Customer" type="text" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-2">Pilih Produk</label>
                                            <div class="col-7">
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input name="produk" id="produk_0" type="radio" class="custom-control-input" value="TV">
                                                    <label for="produk_0" name="tv" class="custom-control-label">TV</label>
                                                </div>
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input name="produk" id="produk_1" type="radio" class="custom-control-input" value="Kulkas">
                                                    <label for="produk_1" name="kulkas" class="custom-control-label">KULKAS</label>
                                                </div>
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input name="produk" id="produk_2" type="radio" class="custom-control-input" value="Mesin Cuci">
                                                    <label for="produk_2" name="mesin_cuci" class="custom-control-label">MESIN CUCI</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="jumlah" class="col-2 col-form-label">Jumlah</label>
                                            <div class="col-7">
                                                <input id="jumlah" name="jumlah" placeholder="Jumlah" type="text" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="offset-2 col-7">
                                                <button name="proses" type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card" style="width: 20rem;">
                                        <div class="card-header text-white bg-primary">
                                            Daftar Harga
                                        </div>
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item">TV : 4.200.000</li>
                                            <li class="list-group-item">kulkas : 3.100.000</li>
                                            <li class="list-group-item">MESIN CUCI : 3.800.000</li>
                                        </ul>
                                        <div class="card-footer text-white bg-primary">
                                            Harga Dapat Berubah Setiap Saat
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br/>
                            <?php
                                error_reporting(0);
                                $customer = $_POST['customer'];
                                $produk = $_POST['produk'];
                                $jumlah = $_POST['jumlah'];

                                //harga
                                if ($produk == 'TV'){
                                    $harga = 4200000;
                                }elseif ($produk == 'Kulkas'){
                                    $harga = 3100000;
                                }elseif ($produk == 'Mesin Cuci'){
                                    $harga = 3800000;
                                }

                                $total = $jumlah * $harga;

                                echo '<br/> Nama Customer : '.$customer; 
                                echo '<br/>Produk Pilihan : '.$produk;
                                echo '<br/>Jumlah Beli : '.$jumlah; 
                                echo '<br/> Total Belanja :'.$total; 
                            ?>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>

<?php
    include_once 'footer.php';
?>