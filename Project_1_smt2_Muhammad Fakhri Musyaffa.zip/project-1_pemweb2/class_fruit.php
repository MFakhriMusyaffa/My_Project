<?php
  include_once 'header.php';
  include_once 'sidebar.php';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Class Fruit</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Class Fruit</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Default box -->
                    <div class="card">
                        <div class="card-body">
                            <?php
                                class fruit{ //nama kelas
                                    public $nama; //obj
                                    public $color; //obj
                                    public function __construct($nama, $color ){ //method
                                        $this->nama = $nama;
                                        $this->color = $color;
                                    }
                                    public function intro(){
                                        echo "<br/>the fruit is {$this->nama} and the color is {$this->color}";
                                    }
                                }

                                class strawberry extends fruit{ //pewaris kelas
                                    public $weight; //obj baru
                                    public function __construct($nama , $color, $weight){ //function baru
                                        $this->nama = $nama;
                                        $this->color = $color;
                                        $this->weight = $weight;
                                    }
                                    public function intro(){
                                        echo "Nama buahnya adalah {$this->nama} dengan warna {$this->color} dan beratnya {$this->weight}";
                                    }
                                }

                                $strawberry = new strawberry ("strawberry", "red", 90);
                                $strawberry -> intro();
                            ?>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>

<?php
  include_once 'footer.php';
?>
